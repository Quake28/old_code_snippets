clear all
close all
clc

% f1 = inline('cos(x)','x');
% f2 = inline('(x.^2).*exp(-x)','x');
% f3 = inline('x.*exp(-2*x.^2)','x');
% f4= inline('20*x.^2+10*x.^3','x');
f5= inline('0.2+25*x-200*x.^2+675*x.^3-900*x.^4+400*x.^5', 'x');
true_value= 1.640;

a = 0;%Lower limit
b = 0.8;%Upper limit
n = 2;%number of segments
h = (b-a)/n;%Width of each segment

%Get the function values for each segment
Y = [];%Y contains the function values
for x=a:h:b
    Y = [Y, f5(x)];
end
%You can also input a tabulated data instead of a function.
integration_result = trapezoidal(Y,h)
