clear all
close all
clc

f1 = inline('cos(x)','x');
f2 = inline('(x.^2).*exp(-x)','x');
f3 = inline('x.*exp(-2*x.^2)','x');
f4= inline('20*x.^2+10*x.^3','x');
true_value= 93.3;

a = 0;%Lower limit
b = 2;%Upper limit
n = 9;%number of segments
h = (b-a)/n;%Width of each segment

%Get the function values for each segment
Y = [];%Y contains the function values
for x=a:h:b
    Y = [Y, f4(x)];
end
%You can also input a tabulated data instead of a function.
simpson_1_3_result = simpson_1_3(Y,h)
simpson_3_8_result = simpson_3_8(Y,h)
